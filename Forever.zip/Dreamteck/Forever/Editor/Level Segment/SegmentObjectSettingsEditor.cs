﻿namespace Dreamteck.Forever.Editor
{
    using UnityEditor;

    [CustomEditor(typeof(SegmentObjectSettings))]
    public class SegmentObjectSettingsEditor : Editor
    {
    }
}
