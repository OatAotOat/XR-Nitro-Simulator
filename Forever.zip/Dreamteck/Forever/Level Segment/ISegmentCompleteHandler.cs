﻿﻿namespace Dreamteck.Forever
{
    public interface ISegmentCompleteHandler
    {
        void OnSegmentComplete(LevelSegment levelSegment);
    }
}