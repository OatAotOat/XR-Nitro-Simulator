﻿using UnityEngine;

namespace Dreamteck.Forever
{
    public class PreventFromUnloading : MonoBehaviour
    {
    }
}