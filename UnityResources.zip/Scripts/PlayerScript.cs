using UnityEngine;
using Dreamteck.Forever;
using UnityEngine.UI;

public class PlayerScript : MonoBehaviour
{
    [HideInInspector] public LaneRunner runner;
    [HideInInspector] public bool HadExploded { get; set; } = false;
    [HideInInspector] public bool NitroHasBoosted { get; set; } = false;
    [HideInInspector] public bool NitroIsNotReady { get; set; } = true;
    [HideInInspector] public int NitroBonus { get; set; } = 1;
    [HideInInspector] public int CoinReceived { get; set; } = 0;

    protected LogicScript logic;
    
    public GameObject gameplayScreen;
    public GameObject explosionEffect;
    public GameObject pyroEffect;

    public AudioSource gotNitroSound;
    public AudioSource gotCoinSound;
    public AudioSource crashPropSound;
    public AudioSource carExplodedSound;

    public ParticleSystem nitroEffect;
    public Slider nitroBar;
    public float radius = 6.5f;
    public float force = 300;

    // Start is called before the first frame update
    void Start()
    {
        runner = GetComponent<LaneRunner>();
        logic = GameObject.FindGameObjectWithTag("Logic").GetComponent<LogicScript>();
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (!HadExploded)
        {
            if (collision.collider.tag == "Dead End" && !NitroHasBoosted)
            {
                runner.follow = false;
                gameplayScreen.SetActive(false);
                Explode();
                HadExploded = true;
            } 
            else if (collision.collider.tag == "Dead End" && NitroHasBoosted)
            {
                int score = Random.Range(5, 10) * 10;
                Debug.Log("Dead End Hit");
                logic.AddScore(score * NitroBonus);
                crashPropSound.Play();
            }

            if (collision.collider.tag == "Obstacle")
            {
                int score = Random.Range(1, 5) * 10;
                Debug.Log("Obstacle Hit");
                logic.AddScore(score * NitroBonus);
                crashPropSound.Play();
            }

            if (collision.collider.gameObject.tag == "Coin")
            {
                CoinReceived++;
                Debug.Log("Got Coin");
                logic.AddScore(10 * NitroBonus);
                Destroy(collision.collider.gameObject);
                gotCoinSound.Play();
            }

            if (collision.collider.gameObject.tag == "Nitro" && NitroIsNotReady)
            {
                nitroBar.value += 0.1f;
                Destroy(collision.collider.gameObject);
                gotNitroSound.Play();
            }
        }
    }

    public void ActivateNitro(bool use)
    {
        if (use)
        {
            nitroEffect.Play();
        } 
        else
        {
            nitroEffect.Stop();
        }
    }

    void Explode()
    {
        carExplodedSound.Play();

        Instantiate(explosionEffect, transform.position, transform.rotation);

        Instantiate(pyroEffect, transform.position, transform.rotation, gameObject.transform);

        Collider[] colliders = Physics.OverlapSphere(transform.position, radius);

        foreach (Collider nearbyObject in colliders)
        {
            Rigidbody rb = nearbyObject.GetComponent<Rigidbody>();
            if (rb != null)
            {
                rb.AddExplosionForce(force, transform.position, radius);
            }
        }
    }

}
