using UnityEngine;

public class CameraScript : MonoBehaviour
{
    protected PlayerScript car;

    public Transform target;
    public Vector3 offset;
    public float speed;
    public float defaultFOV, nitroFOV = 0;
    [Range(0,3)] public float smoothTime = 1;

    void Awake()
    {
        car = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerScript>();
        defaultFOV = Camera.main.fieldOfView;
    }

    void FixedUpdate()
    {
        Follow();
    }

    public void Follow()
    {
        if (target != null)
        {
            speed = Mathf.Lerp(speed, car.runner.followSpeed / 2, Time.deltaTime);

            transform.position = Vector3.Lerp(transform.position, target.position + offset, speed * Time.deltaTime);
        }
    }

    public void FOVEffect(bool useNitro)
    {
        if (useNitro)
        {
            Camera.main.fieldOfView = Mathf.Lerp(Camera.main.fieldOfView, nitroFOV, Time.deltaTime * smoothTime);
        }
        else
        {
            Camera.main.fieldOfView = Mathf.Lerp(Camera.main.fieldOfView, defaultFOV, Time.deltaTime * smoothTime);
        }
    }

}
