using UnityEngine;
using UnityEngine.UI;

public class ControllerScript : MonoBehaviour
{
    private bool speedUp;
    private bool slowDown;
    private bool boosting;
    private bool nitroIsReady = false;
    private float invincibleTimer = 0;

    protected PlayerScript car;
    protected CameraScript cam;

    public Slider nitroBar;
    public GameObject nitroButton;
    public GameObject nitroDisbledButton;
    public GameObject invincibleBarrier;

    public AudioSource boostNitroSound;

    void Start()
    {
        car = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerScript>();
        cam = GameObject.FindGameObjectWithTag("MainCamera").GetComponent<CameraScript>();
        if (PlayerPrefs.GetInt("Super Nitro", 0) == 1)
        {
            nitroBar.value = 0;
            nitroIsReady = true;
        }
    }

    void Update()
    {
        if (Input.GetKeyDown("a")) { TurnLeft(); }
        
        if (Input.GetKeyDown("d")) { TurnRight(); }
    }

    void FixedUpdate()
    {
        if (!car.HadExploded)
        {
            if (speedUp && car.runner.followSpeed < 20)
            {
                car.runner.followSpeed += 0.1f;
            }
        
            if (slowDown && car.runner.followSpeed > 10.5)
            {
                car.runner.followSpeed -= 0.2f;
            }

            NitroStatus();

            if (boosting || nitroBar.value >= 1)
            {
                nitroBar.value -= (nitroBar.value <= 0) ? 0 : Time.deltaTime / 3;
            }

            if (boosting)
            {
                if (nitroBar.value > 0)
                {
                    car.ActivateNitro(true);
                    cam.FOVEffect(true);
                    car.runner.followSpeed = 40;
                }
                else
                {
                    car.ActivateNitro(false);
                    cam.FOVEffect(false);
                    while (car.runner.followSpeed > 20)
                    {
                        car.runner.followSpeed -= 0.2f * Time.deltaTime / 2;
                    }
                }
            }
            else
            {
                car.ActivateNitro(false);
                cam.FOVEffect(false);
                while (car.runner.followSpeed > 20)
                {
                    car.runner.followSpeed -= 0.2f * Time.deltaTime / 2;
                }
            }

            if (!boosting || !nitroIsReady)
            {
                invincibleTimer += Time.deltaTime;
                invincibleBarrier.SetActive(true);
                car.NitroHasBoosted = true;
                if (invincibleTimer > 5)
                {
                    invincibleBarrier.SetActive(false);
                    car.NitroHasBoosted = false;
                }
            }
            else
            {
                invincibleBarrier.SetActive(false);
            }
        }

    }

    public void TurnLeft()
    {
        car.runner.lane--;
    }
    
    public void TurnRight()
    {
        car.runner.lane++;
    }

    public void SpeedUp(bool hold)
    {
        speedUp = hold;
    }

    public void SlowDown(bool hold)
    {
        slowDown = hold;
    }

    public void BoostingNitro(bool hold)
    {
        if (hold && nitroIsReady)
        {
            boostNitroSound.Play();
            boosting = true;
            invincibleTimer = 0;
            car.NitroHasBoosted = true;
            car.NitroBonus = 2;
        }
        else
        {
            boosting = false;
            car.NitroBonus = 1;
        }

    }

    private void NitroStatus()
    {
        if (nitroBar.value == 1)
        {
            nitroIsReady = true;
            car.NitroIsNotReady = false;
            nitroButton.SetActive(true);
            nitroDisbledButton.SetActive(false);
        } 
        else if (nitroBar.value == 0)
        {
            nitroIsReady = false;
            car.NitroIsNotReady = true;
            nitroButton.SetActive(false);
            nitroDisbledButton.SetActive(true);
            BoostingNitro(false);
        }
    }

}
