using Dreamteck.Forever;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PauseScript : MonoBehaviour
{
    protected bool gameIsPaused = false;

    public GameObject pauseScreen;
    public GameObject pauseButton;
    public GameObject controller;
    public GameObject speedSection;

    public AudioSource gamePlayTheme;

    public void Resume()
    {
        pauseScreen.SetActive(false);
        Time.timeScale = 1f;
        this.gameIsPaused = false;
        pauseButton.SetActive(true);
        controller.SetActive(true);
        speedSection.SetActive(true);
        LevelGenerator.instance.enabled = true;
        gamePlayTheme.Play();
    }

    public void Pause()
    {
        pauseScreen.SetActive(true);
        Time.timeScale = 0f;
        this.gameIsPaused = true;
        pauseButton.SetActive(false);
        controller.SetActive(false);
        speedSection.SetActive(false);
        LevelGenerator.instance.enabled = false;
        gamePlayTheme.Pause();
    }

    public void BackToMenu()
    {
        Resume();
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex - 2);
    }
}

