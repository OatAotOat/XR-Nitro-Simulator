using UnityEngine;
using UnityEngine.SceneManagement;

public class LogicScript : MonoBehaviour
{
    private float highScoreTimer = 0;
    private float gameOverTimer = 0;
    private float needleStartPos = 130f, needleEndPos = -130f;
    private float needleCurrentPos;
    private bool newHighScore = false;
    private bool gameHasOver = false;

    protected PlayerScript car;

    public int PlayerScore { get; private set; }
    public TMPro.TMP_Text scoreText;
    public TMPro.TMP_Text highScoreText;
    public TMPro.TMP_Text gameOverScoreText;
    public TMPro.TMP_Text gameOverCoinText;

    public GameObject loadingScreen;
    public GameObject gamePlayScreen;
    public GameObject gameOverScreen;
    public GameObject newHighScoreText;
    public GameObject needle;

    public AudioSource gamePlayTheme;

    void Start()
    {
        car = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerScript>();
        loadingScreen.SetActive(true);
        gamePlayScreen.SetActive(false);
        scoreText.text = PlayerScore.ToString();
        highScoreText.text = string.Format("High Score : " + PlayerPrefs.GetInt("HighScore", 0));
        gamePlayTheme.Play();
    }

    void Update()
    {
        if (car.transform.position.z > 3.5)
        {
            loadingScreen.SetActive(false);
            gamePlayScreen.SetActive(true);
            this.highScoreTimer += Time.deltaTime;
        }

        if (this.highScoreTimer > 5)
        {
            highScoreText.text = string.Empty;
        }

        if (car.HadExploded) 
        {
            gamePlayTheme.Pause();
            gamePlayScreen.SetActive(false);
            this.gameOverTimer += Time.deltaTime;
            if (this.gameOverTimer > 3 && !gameHasOver)
            {
                GameOver();
                gameHasOver = true;
            }
        }
    }

    void FixedUpdate()
    {
        float speed = car.runner.followSpeed * 4.5f;
        needleCurrentPos = needleStartPos - needleEndPos;
        needle.transform.eulerAngles = new Vector3(0, 0, (needleStartPos - speed * needleCurrentPos / 180));
    }

    [ContextMenu("Increase Score")]
    public void AddScore(int score)
    {
        PlayerScore += score * PlayerPrefs.GetInt("Double Score", 1);
        if (!car.HadExploded)
        {
            scoreText.text = PlayerScore.ToString();
        }

        if (PlayerScore > PlayerPrefs.GetInt("HighScore", 0))
        {
            newHighScoreText.SetActive(true);
            PlayerPrefs.SetInt("HighScore", PlayerScore);
            newHighScore = true;
        }
    }

    private void GameOver()
    {
        car.CoinReceived *= PlayerPrefs.GetInt("Double Coin", 1);
        PlayerPrefs.SetInt("Money", car.CoinReceived + PlayerPrefs.GetInt("Money"));
        Debug.Log(PlayerPrefs.GetInt("Money"));
        PlayerPrefs.SetInt("Double Coin", 1);
        PlayerPrefs.SetInt("Double Score", 1);
        PlayerPrefs.SetInt("Super Nitro", 0);
        gameOverScreen.SetActive(true);
        if (newHighScore) { newHighScoreText.SetActive(true); }
        gameOverScoreText.text = PlayerScore.ToString();
        gameOverCoinText.text = car.CoinReceived.ToString();
    }
    public void RestartGame()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

}