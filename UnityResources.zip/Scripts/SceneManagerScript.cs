using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneManagerScript : MonoBehaviour
{
    private bool carIsFound = false;
    private float timer = 0;

    public GameObject foundScreen;
    public TMPro.TMP_Text countdown;

    void Update()
    {
        if (carIsFound)
        {
            foundScreen.SetActive(true);
            timer += Time.deltaTime;
            countdown.text = string.Format("Game Starts In " + ((int) (3 - timer)));
            if (timer >= 3)
            {
                SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
            }
        }
    }
    public void ScanToPlay(bool found)
    {
        carIsFound = found;
    }

    public void BackToMenu()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex - 1);
    }

}
