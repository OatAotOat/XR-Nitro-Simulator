using UnityEngine;
using UnityEngine.SceneManagement;

public class ShopScript : MonoBehaviour
{
    private bool confirm = false;
    private bool buyDoubleCoin = false;
    private bool buyDoubleScore = false;
    private bool buySuperNitro = false;

    public GameObject buyCoin;
    public GameObject buyScore;
    public GameObject buyNitro;

    public GameObject purchasedCoin;
    public GameObject purchasedScore;
    public GameObject purchasedNitro;
    public GameObject confirmScreen;

    public AudioSource cannotBuySound;
    public AudioSource boughtSound;

    public TMPro.TMP_Text money;

    void Start()
    {
        if (PlayerPrefs.HasKey("Money"))
        {
            money.text = PlayerPrefs.GetInt("Money", 0).ToString();
        }
    }

    void Update()
    {
        if (confirm)
        {
            if (buyDoubleCoin)
            {
                PlayerPrefs.SetInt("Money", PlayerPrefs.GetInt("Money", 0) - 9999);
                PlayerPrefs.SetInt("Double Coin", 2);
                buyDoubleCoin = false;
            }

            if (buyDoubleScore)
            {
                PlayerPrefs.SetInt("Money", PlayerPrefs.GetInt("Money", 0) - 5999);
                PlayerPrefs.SetInt("Double Score", 2);
                buyDoubleScore = false;
            }

            if (buySuperNitro)
            {
                PlayerPrefs.SetInt("Money", PlayerPrefs.GetInt("Money", 0) - 7999);
                PlayerPrefs.SetInt("Super Nitro", 1);
                buySuperNitro = false;
            }
            confirm = false;
        }

        if (PlayerPrefs.GetInt("Double Coin", 1) == 2)
        {
            buyCoin.SetActive(false);
            purchasedCoin.SetActive(true);
        }
        else
        {
            buyCoin.SetActive(true);
            purchasedCoin.SetActive(false);
        }

        if (PlayerPrefs.GetInt("Double Score", 1) == 2)
        {
            buyScore.SetActive(false);
            purchasedScore.SetActive(true);
        }
        else
        {
            buyScore.SetActive(true);
            purchasedScore.SetActive(false);
        }

        if (PlayerPrefs.GetInt("Super Nitro", 0) == 1)
        {
            buyNitro.SetActive(false);
            purchasedNitro.SetActive(true);
        }
        else
        {
            buyNitro.SetActive(true);
            purchasedNitro.SetActive(false);
        }

    }

    public void BuyDoubleCoin()
    {
        if (PlayerPrefs.GetInt("Money", 0) > 9999)
        {
            buyDoubleCoin = true;
        } 
        else
        {
            cannotBuySound.Play();
        }
    }

    public void BuyDoubleScore()
    {
        if (PlayerPrefs.GetInt("Money", 0) > 5999)
        {
            buyDoubleScore = true;
            confirmScreen.SetActive(true);
        }
        else
        {
            cannotBuySound.Play();
        }
    }

    public void BuySuperNitro()
    {
        if (PlayerPrefs.GetInt("Money", 0) > 5999)
        {
            buySuperNitro = true;
            confirmScreen.SetActive(true);
        }
        else
        {
            cannotBuySound.Play();
        }
    }

    public void Confirm()
    {
        boughtSound.Play();
        confirm = true;
    }

    public void BackToMenu()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex - 3);
    }
}
