using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    public TMPro.TMP_Text money; 

    void Start()
    {
        if (!PlayerPrefs.HasKey("Double Coin"))
        {
            PlayerPrefs.GetInt("Double Coin", 1);
        }

        if (!PlayerPrefs.HasKey("Double Score"))
        {
            PlayerPrefs.GetInt("Double Score", 1);
        }

        if (!PlayerPrefs.HasKey("Super Nitro"))
        {
            PlayerPrefs.GetInt("Super Nitro", 0);
        }

        if (PlayerPrefs.HasKey("Money"))
        {
            money.text = PlayerPrefs.GetInt("Money").ToString();
        } 
        else
        {
            money.text = PlayerPrefs.GetInt("Money", 0).ToString();
        }
    }

    public void PlayGame()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }

    public void GoToShop()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 3);
    }

    public void QuitGame()
    {
        Application.Quit();
    }

}
