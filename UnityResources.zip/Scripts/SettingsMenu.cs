using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.UI;

public class SettingsMenu : MonoBehaviour
{
    public Slider volumeSlider;
    public Slider effectSlider;

    public AudioMixer audioMixer;
    public AudioMixer effectMixer;

    void Start()
    {
        volumeSlider.value = PlayerPrefs.GetFloat("Volume", -10);
        effectSlider.value = PlayerPrefs.GetFloat("Effect", -15);
    }

    public void SetEffectVolume(float volume)
    {
        PlayerPrefs.SetFloat("Volume", volume);
        effectMixer.SetFloat("effect volume", volume);
    }

    public void SetVolume(float volume)
    {
        PlayerPrefs.SetFloat("Effect", volume);
        audioMixer.SetFloat("volume", volume);
    }
    
}
